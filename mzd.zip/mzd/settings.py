SECRET_KEY = "CHANGEMEFORTHELOVEOFGOD!!!!!!!!!"

ALLOWED_HOSTS = ["*"]  # Could be made more specific


# from pymongo import MongoClient
# from config import MONGO_DB_NAME, MONGO_URL
# from datetime import datetime

# now = datetime.now()

# print(now.date())
# client = MongoClient(MONGO_URL)
# db = client[MONGO_DB_NAME]
# db.user_cover.insert_one({"username" : "shgus79", "covername" : "dd", "cover_url" : "https://mztod.s3.ap-northeast-2.amazonaws.com/cover_dance/park.jpg","created_date" : str(now.date())}) 
